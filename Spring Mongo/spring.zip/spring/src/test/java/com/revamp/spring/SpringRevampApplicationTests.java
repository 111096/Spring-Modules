package com.revamp.spring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringRevampApplicationTests {

	@Test
	void contextLoads() {
	}

}
